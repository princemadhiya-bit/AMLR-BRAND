AMLR BRAND WEBSITE
===================

Files:
- index.html
- logo.webp

Before publishing:
1. Open index.html in a code editor.
2. Replace 919999999999 with your WhatsApp number in BOTH places.
3. Replace the email and Instagram handle.
4. Replace the three demo product blocks/prices with your real products.
5. For real online UPI/card checkout, connect a payment gateway such as Razorpay/Cashfree after setting up your business/payment account.

This version is a mobile-friendly storefront with product cards and WhatsApp ordering.
